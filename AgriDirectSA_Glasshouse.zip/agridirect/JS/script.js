/* ==========================================================================
   AGRIDIRECT SA · MAIN JAVASCRIPT FILE (JS/script.js) · v2 "Glasshouse"
   --------------------------------------------------------------------------
   Vanilla JS, no libraries. Every feature is self-contained and guarded,
   so the same file runs on every page.

    1. Product data (single source for palette, basket, quick view)
    2. Helpers (storage, icons, toasts)
    3. Theme: light / dark toggle (persisted, with ripple wipe)
    4. Sidebar: collapse to icon rail (desktop) / drawer (mobile)
    5. Ambient: preloader, background photo, cursor glow, parallax
    6. Scroll: progress bar, back-to-top ring, reveal, counters
    7. Buttons: ripple + 3D tilt cards
    8. Catalogue: live search, chips, sort, grid/list, favourites
    9. Quick view modal
   10. Quote basket (localStorage) + drawer + fly animation
   11. Command palette (Ctrl/⌘ + K or "/")
   12. Forms: live validation, progress, success state (Enquiry + Contact)
   13. FAQ accordion, testimonials, hubs (open-now, copy), newsletter
   14. Keyboard shortcuts
   ========================================================================== */

(() => {
  'use strict';

  /* 1. PRODUCT DATA ------------------------------------------------------ */
  const PRODUCTS = [
    { id: 'tomatoes',   name: 'Fresh Bulk Tomatoes',     cat: 'vegetables', farm: 'Umngeni Valley Farm',    price: 180, unit: '10kg crate', stock: 45,  stockUnit: 'crates',  loc: 'Midlands, KZN',             img: 'images/tomatoes.jpg' },
    { id: 'spinach',    name: 'Organic Spinach Bundles', cat: 'vegetables', farm: 'Sunshine Organics',      price: 15,  unit: 'bundle',     stock: 100, stockUnit: 'bundles', loc: 'Ballito, KZN',              img: 'images/spinach.jpg' },
    { id: 'butternut',  name: 'Butternut Squash',        cat: 'vegetables', farm: 'Midlands Harvest Co-op', price: 10,  unit: 'each',       stock: 150, stockUnit: 'units',   loc: 'Howick, KZN',               img: 'images/Butternut Squash.jpg' },
    { id: 'onions',     name: 'Red Onions',              cat: 'vegetables', farm: 'Valley Fresh Produce',   price: 90,  unit: '10kg bag',   stock: 70,  stockUnit: 'bags',    loc: 'Cato Ridge, KZN',           img: 'images/Red Onions.jpg' },
    { id: 'potatoes',   name: 'Baby Potatoes',           cat: 'vegetables', farm: 'Greenfield Farms',       price: 75,  unit: '10kg bag',   stock: 90,  stockUnit: 'bags',    loc: 'Underberg, KZN',            img: 'images/potatoes.jpg' },
    { id: 'oranges',    name: 'Valencia Oranges',        cat: 'fruits',     farm: 'Sundown Citrus Estate',  price: 120, unit: '10kg crate', stock: 60,  stockUnit: 'crates',  loc: 'uMhlali, KZN',              img: 'images/Valencia Oranges.jpg' },
    { id: 'bananas',    name: 'Bananas',                 cat: 'fruits',     farm: 'Tropical Coast Farms',   price: 95,  unit: '10kg box',   stock: 55,  stockUnit: 'boxes',   loc: 'Umzimkulu, KZN',            img: 'images/Bananas.jpg' },
    { id: 'apples',     name: 'Red Apples',              cat: 'fruits',     farm: 'Highland Orchards',      price: 140, unit: '10kg crate', stock: 40,  stockUnit: 'crates',  loc: 'Drakensberg Foothills, KZN', img: 'images/Red Apples.jpg' },
    { id: 'watermelon', name: 'Seedless Watermelon',     cat: 'fruits',     farm: 'Sunbelt Melon Farms',    price: 45,  unit: 'each',       stock: 85,  stockUnit: 'units',   loc: 'Jozini, KZN',               img: 'images/Seedless Watermelon.jpg' },
    { id: 'avocados',   name: 'Avocados',                cat: 'fruits',     farm: 'Hillcrest Avo Growers',  price: 160, unit: '10kg crate', stock: 50,  stockUnit: 'crates',  loc: 'Hillcrest, KZN',            img: 'images/Avocados.jpg' },
    { id: 'basil',      name: 'Fresh Basil Bundles',     cat: 'herbs',      farm: 'Green Leaf Herb Co-op',  price: 22,  unit: 'bundle',     stock: 80,  stockUnit: 'bundles', loc: 'Hillcrest, KZN',            img: 'images/Fresh Basil Bundles.jpg' },
    { id: 'coriander',  name: 'Fresh Coriander',         cat: 'herbs',      farm: 'Green Leaf Herb Co-op',  price: 18,  unit: 'bundle',     stock: 95,  stockUnit: 'bundles', loc: 'Hillcrest, KZN',            img: 'images/Fresh Coriander.jpg' },
    { id: 'mint',       name: 'Fresh Mint',              cat: 'herbs',      farm: 'Green Leaf Herb Co-op',  price: 18,  unit: 'bundle',     stock: 70,  stockUnit: 'bundles', loc: 'Hillcrest, KZN',            img: 'images/Fresh Mint.jpg' },
    { id: 'rosemary',   name: 'Rosemary Sprigs',         cat: 'herbs',      farm: 'Berg Herb Gardens',      price: 20,  unit: 'bundle',     stock: 60,  stockUnit: 'bundles', loc: 'Karkloof, KZN',             img: 'images/Rosemary Sprigs.jpg' },
    { id: 'thyme',      name: 'Thyme Sprigs',            cat: 'herbs',      farm: 'Berg Herb Gardens',      price: 20,  unit: 'bundle',     stock: 65,  stockUnit: 'bundles', loc: 'Karkloof, KZN',             img: 'images/Thyme Sprigs.jpg' }
  ];
  const byId = Object.fromEntries(PRODUCTS.map(p => [p.id, p]));

  const PAGES = [
    { name: 'Home',     href: 'Index.html',    hint: 'Featured listings' },
    { name: 'About',    href: 'About.html',    hint: 'Our mission' },
    { name: 'Enquiry',  href: 'Enquiry.html',  hint: 'Request bulk pricing' },
    { name: 'Products', href: 'Products.html', hint: 'Full catalogue' },
    { name: 'Contact',  href: 'Contact.html',  hint: 'Regional hubs & maps' }
  ];

  /* 2. HELPERS ---------------------------------------------------------- */
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const root = document.documentElement;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(pointer: fine)').matches;
  const rand = (n) => Math.round(n).toLocaleString('en-ZA');
  const money = (n) => 'R' + Number(n).toLocaleString('en-ZA');

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* private mode */ } }
  };

  const icon = (id, cls = 'icon') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${id}"/></svg>`;

  function toast(msg, type = 'ok') {
    let wrap = $('.toasts');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toasts'; wrap.setAttribute('aria-live', 'polite'); document.body.appendChild(wrap); }
    const t = document.createElement('div');
    t.className = 'toast glass' + (type === 'error' ? ' error' : '');
    t.innerHTML = `<span class="t-ico">${icon(type === 'error' ? 'alert' : 'check', 'icon icon-sm')}</span><span>${msg}</span>`;
    wrap.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, 3200);
  }

  /* 3. THEME ------------------------------------------------------------ */
  function setTheme(next, origin) {
    if (origin && !reduceMotion) {
      const w = document.createElement('div');
      w.className = 'theme-wipe';
      w.style.left = origin.x + 'px'; w.style.top = origin.y + 'px';
      w.style.background = next === 'dark' ? 'rgba(8,19,13,.55)' : 'rgba(246,243,234,.6)';
      document.body.appendChild(w);
      setTimeout(() => w.remove(), 850);
    }
    root.setAttribute('data-theme', next);
    store.set('agd-theme', next);
    $$('.theme-toggle').forEach(b => {
      b.setAttribute('aria-label', next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
      b.setAttribute('aria-pressed', String(next === 'dark'));
    });
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', next === 'dark' ? '#08130D' : '#E9EEE6');
  }
  const toggleTheme = (e) => {
    const r = e && e.currentTarget ? e.currentTarget.getBoundingClientRect() : null;
    setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', r ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null);
  };

  /* 4. SIDEBAR ---------------------------------------------------------- */
  const isMobile = () => window.matchMedia('(max-width: 900px)').matches;
  function toggleSidebar() {
    if (isMobile()) {
      const open = !root.classList.contains('sb-mobile-open');
      root.classList.toggle('sb-mobile-open', open);
      document.body.classList.toggle('no-scroll', open);
      $$('.sb-toggle').forEach(b => b.setAttribute('aria-expanded', String(open)));
    } else {
      const collapsed = !root.classList.contains('sb-collapsed');
      root.classList.toggle('sb-collapsed', collapsed);
      store.set('agd-sb-collapsed', collapsed);
      $$('.sb-toggle').forEach(b => b.setAttribute('aria-expanded', String(!collapsed)));
    }
  }
  function closeMobileSidebar() {
    root.classList.remove('sb-mobile-open');
    document.body.classList.remove('no-scroll');
  }

  /* overlays registry so Esc closes the top-most thing */
  const overlays = [];
  const scrim = () => {
    let s = $('.scrim');
    if (!s) { s = document.createElement('div'); s.className = 'scrim'; document.body.appendChild(s); s.addEventListener('click', closeAll); }
    return s;
  };
  function openOverlay(el) {
    closeAll();
    el.classList.add('show'); el.setAttribute('aria-hidden', 'false');
    scrim().classList.add('show'); document.body.classList.add('no-scroll');
    overlays.push(el);
    const f = el.querySelector('input, button, a'); if (f) setTimeout(() => f.focus(), 60);
  }
  function closeAll() {
    while (overlays.length) { const el = overlays.pop(); el.classList.remove('show'); el.setAttribute('aria-hidden', 'true'); }
    const s = $('.scrim'); if (s) s.classList.remove('show');
    if (!root.classList.contains('sb-mobile-open')) document.body.classList.remove('no-scroll');
  }

  document.addEventListener('DOMContentLoaded', () => {

    /* theme + sidebar wiring */
    setTheme(root.getAttribute('data-theme') || 'light');
    $$('.theme-toggle').forEach(b => b.addEventListener('click', toggleTheme));
    $$('.sb-toggle').forEach(b => b.addEventListener('click', toggleSidebar));
    const ms = $('.mobile-scrim'); if (ms) ms.addEventListener('click', closeMobileSidebar);
    $$('.side-nav a').forEach(a => a.addEventListener('click', () => isMobile() && closeMobileSidebar()));
    window.addEventListener('resize', () => { if (!isMobile()) closeMobileSidebar(); });

    // follow system theme only if user never chose
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener && mq.addEventListener('change', e => { if (store.get('agd-theme', null) === null) setTheme(e.matches ? 'dark' : 'light'); });

    /* 5. AMBIENT ------------------------------------------------------- */
    const pre = $('.preloader');
    if (pre) {
      const seen = sessionStorage.getItem('agd-seen');
      const hide = () => { pre.classList.add('done'); setTimeout(() => pre.remove(), 700); };
      if (seen || reduceMotion) hide();
      else { sessionStorage.setItem('agd-seen', '1'); window.addEventListener('load', () => setTimeout(hide, 900)); setTimeout(hide, 2600); }
    }

    // blurred photo background: each page names its own photo on <body data-bg>
    const photo = $('.bg-photo');
    if (photo && document.body.dataset.bg) photo.style.backgroundImage = `url("${document.body.dataset.bg}")`;

    const glow = $('.cursor-glow');
    const blobs = $$('.bg-scene .blob');
    if (finePointer && !reduceMotion) {
      let mx = 0, my = 0, gx = 0, gy = 0, raf;
      window.addEventListener('pointermove', (e) => {
        mx = e.clientX; my = e.clientY; document.body.classList.add('has-pointer');
        if (!raf) raf = requestAnimationFrame(loop);
      }, { passive: true });
      const loop = () => {
        gx += (mx - gx) * 0.12; gy += (my - gy) * 0.12;
        if (glow) glow.style.transform = `translate(${gx - 260}px, ${gy - 260}px)`;
        const px = (gx / innerWidth - .5), py = (gy / innerHeight - .5);
        blobs.forEach((b, i) => { b.style.translate = `${px * (i + 1) * 30}px ${py * (i + 1) * 30}px`; });
        raf = (Math.abs(mx - gx) > .5 || Math.abs(my - gy) > .5) ? requestAnimationFrame(loop) : null;
      };
      if (glow) glow.style.left = glow.style.top = '0px';
    }

    /* 6. SCROLL ------------------------------------------------------- */
    const bar = $('.progress-bar');
    const toTop = $('.to-top');
    const ring = toTop ? toTop.querySelector('.ring circle') : null;
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - innerHeight;
      const p = h > 0 ? scrollY / h : 0;
      if (bar) bar.style.transform = `scaleX(${p})`;
      if (toTop) { toTop.classList.toggle('show', scrollY > 500); if (ring) ring.style.strokeDashoffset = String(157 - 157 * p); }
    };
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    if (toTop) toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }));

    // count-up numbers
    const countUp = (el) => {
      const end = parseFloat(el.dataset.count); const dur = 1800; const t0 = performance.now();
      const dec = (el.dataset.count.split('.')[1] || '').length;
      const step = (t) => {
        const k = Math.min(1, (t - t0) / dur); const e = 1 - Math.pow(1 - k, 4);
        el.textContent = (end * e).toLocaleString('en-ZA', { minimumFractionDigits: dec, maximumFractionDigits: dec });
        if (k < 1) requestAnimationFrame(step);
      };
      reduceMotion ? (el.textContent = end.toLocaleString('en-ZA')) : requestAnimationFrame(step);
    };

    const io = 'IntersectionObserver' in window ? new IntersectionObserver((entries) => {
      entries.forEach(en => {
        if (!en.isIntersecting) return;
        const el = en.target;
        el.classList.add('in');
        $$('[data-count]', el).concat(el.matches('[data-count]') ? [el] : []).forEach(n => { if (!n.dataset.done) { n.dataset.done = 1; countUp(n); } });
        $$('.stock .bar i', el).forEach(i => { i.style.width = i.dataset.w; });
        $$('.impact-ring .val', el).forEach(c => { c.style.strokeDashoffset = c.dataset.offset; });
        $$('.season-grid .cell', el).forEach((c, idx) => { c.animate && !reduceMotion && c.animate([{ transform: 'scaleX(0)' }, { transform: 'scaleX(1)' }], { duration: 600, delay: idx * 6, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' }); });
        io.unobserve(el);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }) : null;
    $$('.reveal').forEach(el => io ? io.observe(el) : el.classList.add('in'));
    if (!io) $$('.stock .bar i').forEach(i => { i.style.width = i.dataset.w; });

    // hero headline: split into words for a staggered rise
    const hh = $('#hero h2');
    if (hh && !reduceMotion) {
      let i = 0;
      const walk = (node) => {
        Array.from(node.childNodes).forEach(n => {
          if (n.nodeType === 3) {
            const frag = document.createDocumentFragment();
            n.textContent.split(/(\s+)/).forEach(w => {
              if (!w.trim()) { frag.appendChild(document.createTextNode(w)); return; }
              const s = document.createElement('span'); s.className = 'word'; s.textContent = w;
              s.style.animationDelay = (0.15 + i++ * 0.08) + 's'; frag.appendChild(s);
            });
            n.replaceWith(frag);
          } else if (n.nodeType === 1) walk(n);
        });
      };
      walk(hh);
    }

    /* 7. RIPPLE + TILT ------------------------------------------------- */
    document.addEventListener('pointerdown', (e) => {
      const b = e.target.closest('.btn, #hero a, #cta-section a');
      if (!b || reduceMotion) return;
      const r = b.getBoundingClientRect(); const s = Math.max(r.width, r.height);
      const rp = document.createElement('span'); rp.className = 'ripple';
      rp.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
      b.appendChild(rp); setTimeout(() => rp.remove(), 700);
    });

    if (finePointer && !reduceMotion) {
      $$('[data-tilt]').forEach(card => {
        card.addEventListener('pointermove', (e) => {
          const r = card.getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
          card.style.transform = `perspective(900px) rotateX(${-y * 7}deg) rotateY(${x * 9}deg) translateY(-6px)`;
        });
        card.addEventListener('pointerleave', () => { card.style.transform = ''; });
      });
    }

    /* 8. CATALOGUE ---------------------------------------------------- */
    const searchInput = $('#search');
    const categorySelect = $('#category');
    const filterForm = $('#filter-section form');
    const grid = $('#produce-grid');
    const cards = $$('.product-card');
    const chips = $$('[data-chip]');
    const sortSel = $('#sort');
    const countEl = $('#result-count');
    const empty = $('.empty-state');

    function filterProducts() {
      if (!grid) return;
      const term = searchInput ? searchInput.value.toLowerCase().trim() : '';
      const cat = categorySelect ? categorySelect.value.toLowerCase() : 'all';
      let shown = 0;
      cards.forEach(card => {
        const ok = card.textContent.toLowerCase().includes(term) && (cat === 'all' || card.dataset.category === cat);
        const was = !card.classList.contains('hidden');
        card.classList.toggle('hidden', !ok);
        if (ok) { shown++; if (!was) { card.classList.remove('pop-in'); void card.offsetWidth; card.classList.add('pop-in'); } }
      });
      chips.forEach(c => c.setAttribute('aria-pressed', String(c.dataset.chip === cat)));
      if (countEl) countEl.innerHTML = `<b>${shown}</b> of ${cards.length} listings`;
      if (empty) empty.classList.toggle('show', shown === 0);
      const url = new URL(location.href);
      term ? url.searchParams.set('q', term) : url.searchParams.delete('q');
      cat !== 'all' ? url.searchParams.set('cat', cat) : url.searchParams.delete('cat');
      try { history.replaceState(null, '', url); } catch (e) { /* file:// or sandboxed preview */ }
    }

    function sortProducts() {
      if (!grid || !sortSel) return;
      const v = sortSel.value;
      const val = (c) => byId[c.dataset.id] || {};
      const sorted = cards.slice().sort((a, b) => {
        const A = val(a), B = val(b);
        if (v === 'price-asc') return A.price - B.price;
        if (v === 'price-desc') return B.price - A.price;
        if (v === 'stock') return B.stock - A.stock;
        if (v === 'name') return A.name.localeCompare(B.name);
        return PRODUCTS.indexOf(A) - PRODUCTS.indexOf(B);
      });
      sorted.forEach(c => grid.appendChild(c));
    }

    if (filterForm) {
      const qs = new URLSearchParams(location.search);
      if (qs.get('q') && searchInput) searchInput.value = qs.get('q');
      if (qs.get('cat') && categorySelect) categorySelect.value = qs.get('cat');
      filterForm.addEventListener('submit', (e) => { e.preventDefault(); filterProducts(); toast(`Showing ${$$('.product-card:not(.hidden)').length} matching listings`); });
      searchInput && searchInput.addEventListener('input', filterProducts);
      categorySelect && categorySelect.addEventListener('change', filterProducts);
      chips.forEach(c => c.addEventListener('click', () => { categorySelect.value = c.dataset.chip; filterProducts(); }));
      sortSel && sortSel.addEventListener('change', sortProducts);
      $$('.view-toggle button').forEach(b => b.addEventListener('click', () => {
        $$('.view-toggle button').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
        grid.classList.toggle('list-view', b.dataset.view === 'list');
        store.set('agd-view', b.dataset.view);
      }));
      if (store.get('agd-view', 'grid') === 'list') { const lb = $('.view-toggle [data-view="list"]'); lb && lb.click(); }
      const reset = $('#reset-filters');
      reset && reset.addEventListener('click', () => { searchInput.value = ''; categorySelect.value = 'all'; filterProducts(); searchInput.focus(); });
      filterProducts();
    }

    // favourites
    const favs = new Set(store.get('agd-favs', []));
    $$('.fav-btn').forEach(b => {
      const id = b.closest('[data-id]').dataset.id;
      b.setAttribute('aria-pressed', String(favs.has(id)));
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        favs.has(id) ? favs.delete(id) : favs.add(id);
        b.setAttribute('aria-pressed', String(favs.has(id)));
        store.set('agd-favs', Array.from(favs));
        toast(favs.has(id) ? `Saved ${byId[id].name} to favourites` : `Removed ${byId[id].name} from favourites`);
      });
    });

    /* 10. BASKET (defined before quick view, which uses it) ---------- */
    let basket = store.get('agd-basket', {});
    const basketCount = () => Object.values(basket).reduce((a, b) => a + b, 0);
    const basketTotal = () => Object.entries(basket).reduce((s, [id, q]) => s + (byId[id] ? byId[id].price * q : 0), 0);

    function renderBasket(bump) {
      Object.keys(basket).forEach(k => { if (!byId[k] || basket[k] <= 0) delete basket[k]; });
      store.set('agd-basket', basket);
      const n = basketCount();
      $$('.basket-count').forEach(b => {
        b.textContent = n; b.classList.toggle('show', n > 0);
        if (bump) { b.classList.remove('bump'); void b.offsetWidth; b.classList.add('bump'); }
      });
      const list = $('.drawer-list');
      if (list) {
        list.innerHTML = n === 0
          ? `<div class="drawer-empty"><div class="big">🧺</div><p><strong>Your quote basket is empty.</strong></p><p>Add produce from the catalogue and request one combined quote.</p><a class="btn btn-sm" href="Products.html">Browse produce</a></div>`
          : Object.entries(basket).map(([id, q]) => { const p = byId[id]; return `
            <div class="drawer-item" data-id="${id}">
              <img src="${p.img}" alt="">
              <div><h4>${p.name}</h4><small>${money(p.price)} / ${p.unit}</small></div>
              <div class="qty" aria-label="Quantity"><button type="button" data-q="-1" aria-label="Decrease">−</button><output>${q}</output><button type="button" data-q="1" aria-label="Increase">+</button></div>
            </div>`; }).join('');
      }
      const tot = $('.drawer-total'); if (tot) tot.textContent = money(basketTotal());
      const foot = $('.drawer-foot'); if (foot) foot.style.display = n ? '' : 'none';
      renderEnquirySummary();
    }
    function addToBasket(id, q = 1, fromEl) {
      basket[id] = (basket[id] || 0) + q;
      if (fromEl && !reduceMotion) flyToBasket(fromEl, byId[id].img);
      setTimeout(() => renderBasket(true), reduceMotion ? 0 : 650);
      toast(`${q} × ${byId[id].name} added to your quote basket`);
    }
    function flyToBasket(fromEl, img) {
      const target = $('.basket-btn'); if (!target) return;
      const a = fromEl.getBoundingClientRect(), b = target.getBoundingClientRect();
      const d = document.createElement('div'); d.className = 'fly-dot';
      d.style.left = (a.left + a.width / 2 - 23) + 'px'; d.style.top = (a.top + a.height / 2 - 23) + 'px';
      d.style.backgroundImage = `url("${img}")`;
      document.body.appendChild(d);
      requestAnimationFrame(() => {
        d.style.transform = `translate(${b.left + b.width / 2 - (a.left + a.width / 2)}px, ${b.top + b.height / 2 - (a.top + a.height / 2)}px) scale(.3)`;
        d.style.opacity = '.4';
      });
      setTimeout(() => d.remove(), 820);
    }

    const drawer = $('.drawer');
    $$('.basket-btn').forEach(b => b.addEventListener('click', () => drawer && openOverlay(drawer)));
    if (drawer) {
      drawer.addEventListener('click', (e) => {
        const qb = e.target.closest('[data-q]');
        if (qb) { const id = qb.closest('[data-id]').dataset.id; basket[id] = (basket[id] || 0) + Number(qb.dataset.q); renderBasket(); }
        if (e.target.closest('.drawer-close')) closeAll();
        if (e.target.closest('.drawer-clear')) { basket = {}; renderBasket(); toast('Basket cleared'); }
      });
    }

    $$('.add-btn').forEach(b => b.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = b.closest('[data-id]').dataset.id;
      addToBasket(id, 1, b);
      const old = b.innerHTML; b.classList.add('added'); b.innerHTML = icon('check', 'icon icon-sm') + 'Added';
      setTimeout(() => { b.classList.remove('added'); b.innerHTML = old; }, 1400);
    }));

    /* 9. QUICK VIEW ---------------------------------------------------- */
    const modal = $('.modal');
    let qvQty = 1, qvId = null;
    function openQuickView(id) {
      const p = byId[id]; if (!p || !modal) return;
      qvId = id; qvQty = 1;
      modal.querySelector('.qv-img').src = p.img;
      modal.querySelector('.qv-img').alt = p.name;
      modal.querySelector('.qv-name').textContent = p.name;
      modal.querySelector('.qv-badge').className = 'badge qv-badge badge-' + p.cat;
      modal.querySelector('.qv-badge').textContent = p.cat.charAt(0).toUpperCase() + p.cat.slice(1);
      modal.querySelector('.qv-farm').textContent = p.farm;
      modal.querySelector('.qv-loc').textContent = p.loc;
      modal.querySelector('.qv-stock').textContent = `${p.stock} ${p.stockUnit} available`;
      modal.querySelector('.qv-price').textContent = `${money(p.price)} / ${p.unit}`;
      updQv();
      openOverlay(modal);
    }
    function updQv() {
      if (!modal || !qvId) return;
      modal.querySelector('.qv-qty').textContent = qvQty;
      modal.querySelector('.qv-total').textContent = money(byId[qvId].price * qvQty);
    }
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target.closest('.close-x')) closeAll();
        const q = e.target.closest('[data-qv]');
        if (q) { qvQty = Math.max(1, Math.min(byId[qvId].stock, qvQty + Number(q.dataset.qv))); updQv(); }
        if (e.target.closest('.qv-add')) { const btn = e.target.closest('.qv-add'); addToBasket(qvId, qvQty, btn); setTimeout(closeAll, 300); }
      });
    }
    $$('.quick-btn').forEach(b => b.addEventListener('click', (e) => { e.stopPropagation(); openQuickView(b.closest('[data-id]').dataset.id); }));

    renderBasket();

    /* 11. COMMAND PALETTE ---------------------------------------------- */
    const pal = $('.palette');
    const palInput = pal ? $('input', pal) : null;
    const palList = pal ? $('.palette-results', pal) : null;
    let palSel = 0;
    function renderPalette() {
      const q = palInput.value.toLowerCase().trim();
      const pages = PAGES.filter(p => (p.name + p.hint).toLowerCase().includes(q));
      const prods = PRODUCTS.filter(p => (p.name + p.farm + p.loc + p.cat).toLowerCase().includes(q)).slice(0, 7);
      const acts = [
        { label: 'Toggle light / dark mode', act: 'theme', ico: 'moon' },
        { label: 'Open quote basket', act: 'basket', ico: 'basket' },
        { label: 'Collapse / expand sidebar', act: 'sidebar', ico: 'sidebar' }
      ].filter(a => a.label.toLowerCase().includes(q));
      let html = '';
      if (pages.length) html += '<div class="grp">Pages</div>' + pages.map(p => `<a class="p-item" href="${p.href}">${icon('arrow-right', 'icon icon-sm')}<span>${p.name}</span><small>${p.hint}</small></a>`).join('');
      if (prods.length) html += '<div class="grp">Produce</div>' + prods.map(p => `<a class="p-item" href="Products.html?q=${encodeURIComponent(p.name.toLowerCase())}"><img src="${p.img}" alt=""><span>${p.name}</span><small>${money(p.price)} / ${p.unit}</small></a>`).join('');
      if (acts.length) html += '<div class="grp">Actions</div>' + acts.map(a => `<button type="button" class="p-item" data-act="${a.act}">${icon(a.ico, 'icon icon-sm')}<span>${a.label}</span></button>`).join('');
      palList.innerHTML = html || `<div class="drawer-empty"><div class="big">🌾</div>No matches for “${palInput.value}”.</div>`;
      palSel = 0; markSel();
    }
    function markSel() { $$('.p-item', palList).forEach((el, i) => el.classList.toggle('sel', i === palSel)); const s = $$('.p-item', palList)[palSel]; s && s.scrollIntoView({ block: 'nearest' }); }
    function openPalette() { if (!pal) return; openOverlay(pal); palInput.value = ''; renderPalette(); setTimeout(() => palInput.focus(), 50); }
    if (pal) {
      palInput.addEventListener('input', renderPalette);
      palInput.addEventListener('keydown', (e) => {
        const items = $$('.p-item', palList);
        if (e.key === 'ArrowDown') { e.preventDefault(); palSel = (palSel + 1) % items.length; markSel(); }
        if (e.key === 'ArrowUp') { e.preventDefault(); palSel = (palSel - 1 + items.length) % items.length; markSel(); }
        if (e.key === 'Enter') { e.preventDefault(); items[palSel] && items[palSel].click(); }
      });
      palList.addEventListener('click', (e) => {
        const a = e.target.closest('[data-act]'); if (!a) return;
        const act = a.dataset.act; closeAll();
        if (act === 'theme') toggleTheme();
        if (act === 'basket' && drawer) setTimeout(() => openOverlay(drawer), 50);
        if (act === 'sidebar') toggleSidebar();
      });
    }
    $$('.search-trigger').forEach(b => b.addEventListener('click', openPalette));

    /* 12. FORMS ------------------------------------------------------- */
    const rules = {
      'full-name': v => v.length >= 2 || 'Please enter your full name',
      'business-name': v => v.length >= 2 || 'Tell us your business or farm name',
      'email': v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) || 'That email address doesn’t look right',
      'phone': v => /^(\+27|0)[\s-]?\d{2}[\s-]?\d{3}[\s-]?\d{4}$/.test(v.replace(/[()]/g, '')) || 'Use a SA number, e.g. +27 82 123 4567',
      'produce-details': v => v.length >= 15 || 'Add a bit more detail (at least 15 characters)',
      'cname': v => v.length >= 2 || 'Please enter your name',
      'cemail': v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) || 'That email address doesn’t look right',
      'cmsg': v => v.length >= 10 || 'Your message is a little short'
    };
    function check(input, show) {
      const fn = rules[input.id]; if (!fn) return true;
      const res = fn(input.value.trim());
      const field = input.closest('.field');
      if (field) {
        const msg = field.querySelector('.msg');
        if (show || field.classList.contains('touched')) {
          field.classList.toggle('invalid', res !== true);
          field.classList.toggle('valid', res === true);
          if (msg) msg.textContent = res === true ? '' : res;
        }
      }
      input.setAttribute('aria-invalid', String(res !== true));
      return res === true;
    }
    function wireForm(form, onSuccess) {
      if (!form) return;
      form.setAttribute('novalidate', '');
      const inputs = $$('input, textarea', form).filter(i => rules[i.id]);
      const prog = form.parentElement.querySelector('.form-progress i');
      const update = () => { if (prog) prog.style.width = (inputs.filter(i => rules[i.id](i.value.trim()) === true).length / inputs.length * 100) + '%'; };
      inputs.forEach(i => {
        i.addEventListener('blur', () => { i.closest('.field') && i.closest('.field').classList.add('touched'); check(i, true); });
        i.addEventListener('input', () => { check(i); update(); const c = i.closest('.field') && i.closest('.field').querySelector('.counter'); if (c) c.textContent = `${i.value.length} / ${i.maxLength > 0 ? i.maxLength : 500}`; });
      });
      update();
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const bad = inputs.filter(i => !check(i, true));
        if (bad.length) {
          bad.forEach(i => { const f = i.closest('.field'); f.classList.add('touched'); f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake'); });
          bad[0].focus();
          toast(bad.length === 1 ? 'One field needs attention' : `${bad.length} fields need attention`, 'error');
          return;
        }
        const btn = form.querySelector('[type="submit"]');
        const old = btn.innerHTML; btn.disabled = true; btn.innerHTML = 'Sending…';
        setTimeout(() => { btn.disabled = false; btn.innerHTML = old; onSuccess(form); }, 900);
      });
    }

    // Enquiry
    const enquiryForm = $('#enquiry-form-section form');
    wireForm(enquiryForm, (form) => {
      const fullName = $('#full-name').value.trim();
      const email = $('#email').value.trim();
      const role = $('#user-role').value === 'farmer' ? 'farmer' : 'buyer';
      const card = $('#enquiry-success');
      if (card) {
        $('.s-name', card).textContent = fullName.split(' ')[0];
        $('.s-role', card).textContent = role;
        $('.s-email', card).textContent = email;
        $('.s-ref', card).textContent = 'AGD-' + Date.now().toString(36).toUpperCase().slice(-6);
        form.style.display = 'none'; card.classList.add('show');
        const pg = form.parentElement.querySelector('.form-progress'); if (pg) pg.style.display = 'none';
        card.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
      }
      toast(`Thank you, ${fullName}! Your enquiry has been submitted.`);
      basket = {}; renderBasket();
      form.reset(); $$('.field', form).forEach(f => f.classList.remove('valid', 'invalid', 'touched'));
    });
    const again = $('#enquiry-again');
    again && again.addEventListener('click', () => { $('#enquiry-success').classList.remove('show'); enquiryForm.style.display = ''; const pg = enquiryForm.parentElement.querySelector('.form-progress'); if (pg) { pg.style.display = ''; pg.querySelector('i').style.width = '0'; } syncRole(); });

    // role segmented control mirrors the original <select id="user-role">
    const roleSel = $('#user-role');
    const syncRole = () => {
      if (!roleSel) return;
      const r = $(`input[name="role-ui"][value="${roleSel.value}"]`); if (r) r.checked = true;
      const lbl = $('label[for="produce-details"]');
      const ta = $('#produce-details');
      if (lbl && ta) {
        lbl.textContent = roleSel.value === 'farmer' ? 'Produce & Quantity Offered:' : 'Produce & Quantity Needed:';
        ta.placeholder = roleSel.value === 'farmer' ? 'e.g. Supplying 200 bundles of spinach weekly from Ballito' : 'e.g. Requiring 50 crates of bulk tomatoes weekly in Durban';
      }
    };
    $$('input[name="role-ui"]').forEach(r => r.addEventListener('change', () => { roleSel.value = r.value; syncRole(); }));
    syncRole();

    // basket → enquiry prefill
    function renderEnquirySummary() {
      const box = $('#basket-summary'); if (!box) return;
      const entries = Object.entries(basket);
      box.innerHTML = entries.length
        ? '<ul class="basket-summary">' + entries.map(([id, q]) => { const p = byId[id]; return `<li><img src="${p.img}" alt=""><div><strong>${p.name}</strong><br><small>${q} × ${money(p.price)} / ${p.unit}</small></div><b>${money(p.price * q)}</b></li>`; }).join('') + `</ul><p style="margin-top:14px;display:flex;justify-content:space-between"><span class="muted">Estimated total</span><b style="font-family:var(--font-display);font-size:1.4rem">${money(basketTotal())}</b></p><button type="button" class="btn btn-ghost btn-sm btn-block" id="use-basket">${icon('sparkle', 'icon icon-sm')}Fill details from basket</button>`
        : `<p class="muted">Nothing in your quote basket yet. Add items from the <a href="Products.html">catalogue</a> and they’ll appear here.</p>`;
      const ub = $('#use-basket');
      ub && ub.addEventListener('click', () => {
        const ta = $('#produce-details');
        ta.value = 'Quote request:\n' + entries.map(([id, q]) => `• ${q} × ${byId[id].name} (${byId[id].unit}) from ${byId[id].farm}`).join('\n') + `\nEstimated total: ${money(basketTotal())}`;
        ta.dispatchEvent(new Event('input')); ta.focus();
        toast('Basket copied into your enquiry');
      });
    }
    renderEnquirySummary();
    if (new URLSearchParams(location.search).get('from') === 'basket') { const ub = $('#use-basket'); ub && setTimeout(() => ub.click(), 400); }

    // Contact
    const contactForm = $('#general-contact-form form');
    wireForm(contactForm, (form) => {
      toast(`Thank you ${$('#cname').value.trim()}, your message has been sent to our support team.`);
      form.reset(); $$('.field', form).forEach(f => f.classList.remove('valid', 'invalid', 'touched'));
      const p = form.parentElement.querySelector('.form-progress i'); if (p) p.style.width = '0';
    });

    /* 13. FAQ, QUOTES, HUBS, NEWSLETTER ------------------------------- */
    $$('.faq-item h3 button').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.closest('.faq-item'); const open = !item.classList.contains('open');
        item.classList.toggle('open', open); btn.setAttribute('aria-expanded', String(open));
      });
    });

    const quotes = $$('.quote'); const dots = $$('.quote-dots button');
    if (quotes.length) {
      let qi = 0, timer;
      const show = (i) => { qi = i; quotes.forEach((q, k) => q.classList.toggle('active', k === i)); dots.forEach((d, k) => { d.classList.toggle('active', k === i); d.setAttribute('aria-current', String(k === i)); }); };
      const next = () => show((qi + 1) % quotes.length);
      dots.forEach((d, i) => d.addEventListener('click', () => { show(i); clearInterval(timer); timer = setInterval(next, 6000); }));
      show(0); if (!reduceMotion) timer = setInterval(next, 6000);
    }

    // open-now badges (Mon–Fri 08:00–17:00, SAST)
    $$('.open-now').forEach(b => {
      const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Africa/Johannesburg' }));
      const d = now.getDay(), h = now.getHours() + now.getMinutes() / 60;
      const open = d >= 1 && d <= 5 && h >= 8 && h < 17;
      b.classList.add(open ? 'open' : 'closed');
      b.innerHTML = `<span class="live-dot" style="display:inline-block;width:7px;height:7px;border-radius:50%;background:currentColor"></span>${open ? 'Open now' : 'Closed now'}`;
    });

    $$('.copy-btn').forEach(b => b.addEventListener('click', async () => {
      const txt = b.dataset.copy;
      try { await navigator.clipboard.writeText(txt); } catch (e) {
        const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove();
      }
      const old = b.innerHTML; b.innerHTML = icon('check', 'icon icon-sm') + 'Copied'; setTimeout(() => (b.innerHTML = old), 1400);
      toast(`Copied ${txt}`);
    }));

    const nl = $('.newsletter');
    nl && nl.addEventListener('submit', (e) => {
      e.preventDefault(); const i = $('input', nl);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(i.value.trim())) { toast('Enter a valid email for harvest alerts', 'error'); i.focus(); return; }
      toast('You’re in! Weekly harvest alerts are on their way 🌱'); nl.reset();
    });

    // harvest calendar: highlight current month
    const m = new Date().getMonth();
    $$('.season-grid .m').forEach((el, i) => el.classList.toggle('now', i === m));

    // CTA floating seeds
    const seeds = $('#cta-section .seeds');
    if (seeds && !reduceMotion) for (let i = 0; i < 18; i++) {
      const s = document.createElement('span');
      s.style.left = Math.random() * 100 + '%'; s.style.animationDuration = (6 + Math.random() * 8) + 's';
      s.style.animationDelay = (-Math.random() * 10) + 's'; const z = 4 + Math.random() * 10; s.style.width = s.style.height = z + 'px';
      seeds.appendChild(s);
    }

    /* 14. KEYBOARD SHORTCUTS ------------------------------------------ */
    document.addEventListener('keydown', (e) => {
      const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPalette(); return; }
      if (e.key === 'Escape') { closeAll(); closeMobileSidebar(); return; }
      if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === '/') { e.preventDefault(); openPalette(); }
      else if (e.key.toLowerCase() === 't') toggleTheme();
      else if (e.key === '[') toggleSidebar();
      else if (e.key.toLowerCase() === 'b' && drawer) openOverlay(drawer);
      else if (/^[1-5]$/.test(e.key)) location.href = PAGES[Number(e.key) - 1].href;
    });
  });
})();
